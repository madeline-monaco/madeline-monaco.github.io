$(document).ready(function () {

// 1. Select facility city. if it's not selected, use a zip code (make sure it's 5 numbers long)

// 2. Select a date

// 2a. If date is not an NY zip code, alert with "Not available in this area"

// 3. Click submit. (Zip OR bourough) AND date

// 4. If zip code, show map of 10 open markets near there.

// 5. If borough, show map of all open markets there.

// $("#submit").click(function(){
//     debugger;
//     var cityZipCode = $('.input2').val(); 
// });
debugger;

var cityZipCode = $('.zip').val();


// var cityZipCode = this.getElementById("input2").val(); 
var submitButton = this.getElementById("submit");
    submitButton.addEventListener("click", function(cityZipCode){
        debugger; 

    });


var cityZipCode = $('.input2').val(); 

$.ajax({
    url: "https://data.cityofnewyork.us/resource/cw3p-q2v6.json" + cityZipCode,
    type: "GET",
    data: {
      "$limit" : 5000,
      "$$app_token" : "XwT0Lay3rgqSQO1Yt0PZwqopY"      
    }
});
})